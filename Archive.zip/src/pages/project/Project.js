// styles
import './Project.css'

export default function Project() {
  return (
    <div>
      Project details
    </div>
  )
}
