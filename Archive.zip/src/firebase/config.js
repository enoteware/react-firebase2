import firebase from 'firebase/app'
import 'firebase/firestore'
import 'firebase/auth'
import 'firebase/storage'

const firebaseConfig = {
  apiKey: 'AIzaSyCFOBkTsjLRMb409nESwNT6_oaa3wykhSc',
  authDomain: 'dojosite-d8c1e.firebaseapp.com',
  projectId: 'dojosite-d8c1e',
  storageBucket: 'dojosite-d8c1e.appspot.com',
  messagingSenderId: '342458536920',
  appId: '1:342458536920:web:66b340fdd1519d0aeed8ad',
}
// init firebase
firebase.initializeApp(firebaseConfig)

// init services
const projectFirestore = firebase.firestore()
const projectAuth = firebase.auth()
const projectStorage = firebase.storage()

// timestamp
const timestamp = firebase.firestore.Timestamp

export { projectFirestore, projectAuth, timestamp, projectStorage }
